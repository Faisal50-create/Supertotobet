---
title: "⚽️Online, Time and Date "
date: 2025-07-21T04:42:25.102Z
publishDate: 2025-07-21T05:57:02.918Z
author: "Faisal Khan "
description: "What time do America and Cruz Azul play ? Saturday, March 23, 2024
  8:00 PM Central Mexico Time América vs Cruz Azul Streaming : Where to Watch?
  This great game is broadcast LIVE on ESPN and STAR+ , on all their platforms."
---

What time do America   and Cruz Azul play ?
Saturday, March 23, 2024
8:00 PM Central Mexico Time
América vs Cruz Azul Streaming : Where to Watch?
This great game is broadcast LIVE  on  ESPN  and  STAR+ , on all their platforms.

Last 3 results Boca Juniors
Boca Juniors 4-2 Racing Club
Unión Santa Fe 1-0 Boca Juniors
Boca Juniors 3-2 Belgrano
Last 3 results North Central
Juventud Antoniana 0-2 North Central
Central Norte 1-0 Gimnasia Jujuy
Douglas Haig 5-0 North Central﻿This Saturday, March 23, 2024, at 8:00 PM (Miami Time), América will face Cruz Azul at Dignity Health Sports Park. The match is part of the Eagle Tour. You can watch it live with Jeinz Macías .